#!/bin/bash

# Wait for MariaDB to be ready
echo "Waiting for MariaDB..."
until mysqladmin ping -h mariadb -u ${MYSQL_USER} -p${MYSQL_PASSWORD} &>/dev/null; do
    sleep 3
done
echo "MariaDB is ready!"

# Download WordPress if not exists
if [ ! -f "/var/www/html/wp-config.php" ]; then
    echo "Installing WordPress..."
    
    wp core download --allow-root
    
    # Configure WordPress
    wp config create \
        --dbname=${MYSQL_DATABASE} \
        --dbuser=${MYSQL_USER} \
        --dbpass=${MYSQL_PASSWORD} \
        --dbhost=mariadb:3306 \
        --allow-root
    
    # Install WordPress
    wp core install \
        --url=${DOMAIN_NAME} \
        --title="Hello Inception anas " \
        --admin_user=${WP_ADMIN_USER} \
        --admin_password=${WP_ADMIN_PASSWORD} \
        --admin_email=${WP_ADMIN_EMAIL} \
        --allow-root
    
    # Create second user
    wp user create ${WP_USER} ${WP_EMAIL} \
        --role=author \
        --user_pass=${WP_PASSWORD} \
        --allow-root

    # here i add an exmple for other users if needed
    #  and you have to add it also in the .env 
    # in role they are even to 5 role like : contributer and subscriber  
      
        wp user create ${WP_USER_3} ${WP_EMAIL_3} \
        --role=author \
        --user_pass=${WP_PASSWORD_3} \
        --allow-root

    echo "WordPress installed!"
fi

# Start PHP-FPM in foreground
exec php-fpm7.4 -F
